/* *
 * This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK (v2).
 * Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
 * session persistence, api calls, and more.
 * */
const Alexa = require('ask-sdk-core');


//*********************Bienvenido******************************************************************
const DOCUMENT_ID1 = "Bienvenidx";

const datasource1 = {
    "headlineTemplateData": {
        "type": "object",
        "objectId": "headlineSample",
        "properties": {
            "backgroundImage": {
                "contentDescription": null,
                "smallSourceUrl": null,
                "largeSourceUrl": null,
                "sources": [
                    {
                        "url": "https://plus.unsplash.com/premium_photo-1664194584355-25196f114804?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8Zm9uZG8lMjBkZSUyMHBhbnRhbGxhJTIwZGUlMjBndWl0YXJyYXxlbnwwfHwwfHx8MA%3D%3D&w=1000&q=80",
                        "size": "large"
                    }
                ]
            },
            "textContent": {
                "primaryText": {
                    "type": "PlainText",
                    "text": "Hola, conoce los instrumentos musicales."
                }
            },
            "logoUrl": "https://img2.freepng.es/20180723/krb/kisspng-logo-brand-angle-black-hair-font-instrumentos-musicales-5b564605669b30.2488490515323806774203.jpg",
            "hintText": "Puedes consultar información sobre los instrumentos",
            "welcomeSpeechSSML": "<speak><amazon:emotion name='excited' intensity='medium'>Welcome to The Daily Plant Facts</amazon:emotion></speak>"
        },
        "transformers": [
            {
                "inputPath": "welcomeSpeechSSML",
                "transformer": "ssmlToSpeech",
                "outputName": "welcomeSpeech"
            }
        ]
    }
};

const createDirectivePayload1 = (aplDocumentId, dataSources = {}, tokenId = "documentToken") => {
    return {
        type: "Alexa.Presentation.APL.RenderDocument",
        token: tokenId,
        document: {
            type: "Link",
            src: "doc://alexa/apl/documents/" + aplDocumentId
        },
        datasources: dataSources
    }
};
//*********************Fin Bienvenido******************************************************************

//*********************Ayuda******************************************************************
const DOCUMENT_ID2 = "Ayuda";

const datasource2 = {
    "headlineExampleData": {
        "type": "object",
        "backgroundImage": "https://p4.wallpaperbetter.com/wallpaper/966/563/599/musical-instrument-guitar-string-instrument-wood-wallpaper-preview.jpg",
        "logoUrl": "https://img2.freepng.es/20180723/krb/kisspng-logo-brand-angle-black-hair-font-instrumentos-musicales-5b564605669b30.2488490515323806774203.jpg",
        "textContent": {
            "primaryText": "Puedes pedirme información sobre otro instrumento"
        }
    }
};

const createDirectivePayload2 = (aplDocumentId, dataSources = {}, tokenId = "documentToken") => {
    return {
        type: "Alexa.Presentation.APL.RenderDocument",
        token: tokenId,
        document: {
            type: "Link",
            src: "doc://alexa/apl/documents/" + aplDocumentId
        },
        datasources: dataSources
    }
};
//*********************Fin Ayuda******************************************************************

//*********************Fallback******************************************************************
const DOCUMENT_ID3 = "Fallback";

const datasource3 = {
    "headlineExampleData": {
        "type": "object",
        "backgroundImage": "https://w0.peakpx.com/wallpaper/0/91/HD-wallpaper-violin-fotos-arte.jpg",
        "logoUrl": "https://img2.freepng.es/20180723/krb/kisspng-logo-brand-angle-black-hair-font-instrumentos-musicales-5b564605669b30.2488490515323806774203.jpg",
        "textContent": {
            "primaryText": "Lo siento, no puedo ayudarte con eso. Por favor intenta con otro instrumento."
        }
    }
};

const createDirectivePayload3 = (aplDocumentId, dataSources = {}, tokenId = "documentToken") => {
    return {
        type: "Alexa.Presentation.APL.RenderDocument",
        token: tokenId,
        document: {
            type: "Link",
            src: "doc://alexa/apl/documents/" + aplDocumentId
        },
        datasources: dataSources
    }
};

//*********************Fin Fallback******************************************************************

//*********************Cancelar******************************************************************
const DOCUMENT_ID4 = "Cancelar";

const datasource4 = {
    "headlineExampleData": {
        "type": "object",
        "backgroundImage": "https://wallpaperaccess.com/full/1133481.jpg",
        "logoUrl": "https://img2.freepng.es/20180723/krb/kisspng-logo-brand-angle-black-hair-font-instrumentos-musicales-5b564605669b30.2488490515323806774203.jpg",
        "textContent": {
            "primaryText": "Hasta pronto, espero haberte ayudado."
        }
    }
};

const createDirectivePayload4 = (aplDocumentId, dataSources = {}, tokenId = "documentToken") => {
    return {
        type: "Alexa.Presentation.APL.RenderDocument",
        token: tokenId,
        document: {
            type: "Link",
            src: "doc://alexa/apl/documents/" + aplDocumentId
        },
        datasources: dataSources
    }
};
//*********************Fin Cancelar******************************************************************

//*********************Error******************************************************************
const DOCUMENT_ID5 = "Error";

const datasource5 = {
    "headlineExampleData": {
        "type": "object",
        "backgroundImage": "https://s1.1zoom.me/big0/748/Musical_Instruments_458901.jpg",
        "logoUrl": "https://img2.freepng.es/20180723/krb/kisspng-logo-brand-angle-black-hair-font-instrumentos-musicales-5b564605669b30.2488490515323806774203.jpg",
        "textContent": {
            "primaryText": "Lo siento hubo un error,por favor intenta nuevamente."
        }
    }
};

const createDirectivePayload5 = (aplDocumentId, dataSources = {}, tokenId = "documentToken") => {
    return {
        type: "Alexa.Presentation.APL.RenderDocument",
        token: tokenId,
        document: {
            type: "Link",
            src: "doc://alexa/apl/documents/" + aplDocumentId
        },
        datasources: dataSources
    }
};
//*********************Fin Error******************************************************************

//*********************Instrumentos******************************************************************
const DOCUMENT_ID6 = "Instrumentos";

const datasource6 = {
    "headlineExampleData": {
        "type": "object",
        "backgroundImage": "https://images.vexels.com/content/148524/preview/flat-musical-instruments-collection-ad9f55.png",
        "logoUrl": "https://img2.freepng.es/20180723/krb/kisspng-logo-brand-angle-black-hair-font-instrumentos-musicales-5b564605669b30.2488490515323806774203.jpg",
        "textContent": {
            "primaryText": ""
        }
    }
};

const createDirectivePayload6 = (aplDocumentId, dataSources = {}, tokenId = "documentToken") => {
    return {
        type: "Alexa.Presentation.APL.RenderDocument",
        token: tokenId,
        document: {
            type: "Link",
            src: "doc://alexa/apl/documents/" + aplDocumentId
        },
        datasources: dataSources
    }
};
//*********************Fin Instrumentos******************************************************************












const instrumentos ={
    "piano":[
        "El piano moderno tal como lo conocemos fue desarrollado por Bartolomeo Cristofori en Italia alrededor de 1700.",
        "Un piano típico tiene alrededor de 12,000 piezas individuales.",
        "El pianista más joven en grabar un álbum fue Alma Deutscher, quien a los 8 años de edad lanzó su primer álbum de composiciones originales en 2013."
    ],
    "guitarra":[
        "La guitarra más antigua conocida, que data de alrededor del año 1500, se encuentra en el Museo de la Música de Barcelona.",
        "La guitarra eléctrica fue inventada en 1931 por George Beauchamp y Adolph Rickenbacker.",
        "El récord mundial Guinness para la mayor cantidad de guitarras tocando juntas en un solo lugar se estableció en Wroclaw, Polonia, en 2009, con 6,346 guitarristas."
    ],  
    "violin":[
        "El violín más famoso y valioso del mundo es el 'Messiah' Stradivarius, fabricado en 1716 por Antonio Stradivari. Nunca se ha vendido y se encuentra en exhibición en el Museo Ashmolean en Oxford, Reino Unido.",
        "El récord mundial Guinness para el concierto de violines más grande se estableció en 2015 en Poznan, Polonia, con 7,588 violinistas interpretando juntos."
    ],
    "bateria":[
        "La batería moderna, con su configuración actual de bombo, caja, toms y platillos, fue desarrollada a principios del siglo XX.",
        "El baterista más rápido registrado en la historia es Tom Grosset, quien alcanzó una velocidad de 1,260 golpes por minuto en 1992."
    ],
    "flauta":[
        "La flauta más antigua conocida es una flauta de hueso de 43,000 años de antigüedad descubierta en Eslovenia.",
        "El flautista más destacado de la historia es probablemente el compositor alemán Johann Joachim Quantz, quien era flautista de la corte del rey Federico el Grande de Prusia en el siglo XVIII."
    ],
}


const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
    },
    handle(handlerInput) {
        const speakOutput = 'Bienvenido, te puedo mostrar información sobre los instrumentos';
        
            if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            // generate the APL RenderDocument directive that will be returned from your skill
            const aplDirective = createDirectivePayload1(DOCUMENT_ID1, datasource1);
            // add the RenderDocument directive to the responseBuilder
            handlerInput.responseBuilder.addDirective(aplDirective);
        }
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const informacionInstrumentosIntentHandler = {
  
    canHandle(handlerInput){
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
        && Alexa.getIntentName(handlerInput.requestEnvelope) === 'informacionInstrumentosIntent';
    },
    handle(handlerInput){
        const {instrum} = handlerInput.requestEnvelope.request.intent.slots;
        let response;
        if(instrum && instrumentos[instrum.value]){
            response = instrumentos[instrum.value][Math.floor(Math.random() * instrumentos[instrum.value].length)]
            
        if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            // generate the APL RenderDocument directive that will be returned from your skill
            const aplDirective = createDirectivePayload6(DOCUMENT_ID6, datasource6);
            // add the RenderDocument directive to the responseBuilder
            handlerInput.responseBuilder.addDirective(aplDirective);
        }
            
        } else {
           
            response = "Lo siento, no puedo ayudarte con eso. Por favor intenta con otro instrumento."
              if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            // generate the APL RenderDocument directive that will be returned from your skill
            const aplDirective = createDirectivePayload3(DOCUMENT_ID3, datasource3);
            // add the RenderDocument directive to the responseBuilder
            handlerInput.responseBuilder.addDirective(aplDirective);
        }
        }
        return handlerInput.responseBuilder
            .speak(response )
            .reprompt(response)
            .getResponse();
    }
};

const HelpIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'Puedes pedirme otra tipo de instrumento, por ejemplo, dime algo del piano o que sabes sobre el violin';
        
         if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            // generate the APL RenderDocument directive that will be returned from your skill
            const aplDirective = createDirectivePayload2(DOCUMENT_ID2, datasource2);
            // add the RenderDocument directive to the responseBuilder
            handlerInput.responseBuilder.addDirective(aplDirective);
        }

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
                || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const speakOutput = 'Hasta pronto, espero haberte ayudado.';
        
           if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            // generate the APL RenderDocument directive that will be returned from your skill
            const aplDirective = createDirectivePayload4(DOCUMENT_ID4, datasource4);
            // add the RenderDocument directive to the responseBuilder
            handlerInput.responseBuilder.addDirective(aplDirective);
        }

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};
/* *
 * FallbackIntent triggers when a customer says something that doesn’t map to any intents in your skill
 * It must also be defined in the language model (if the locale supports it)
 * This handler can be safely added but will be ingnored in locales that do not support it yet 
 * */
const FallbackIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.FallbackIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'Lo siento, no puedo ayudarte con eso. Por favor, intenta con otro instrumento.';

         if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            // generate the APL RenderDocument directive that will be returned from your skill
            const aplDirective = createDirectivePayload3(DOCUMENT_ID3, datasource3);
            // add the RenderDocument directive to the responseBuilder
            handlerInput.responseBuilder.addDirective(aplDirective);
        }
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};
/* *
 * SessionEndedRequest notifies that a session was ended. This handler will be triggered when a currently open 
 * session is closed for one of the following reasons: 1) The user says "exit" or "quit". 2) The user does not 
 * respond or says something that does not match an intent defined in your voice model. 3) An error occurs 
 * */
const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        console.log(`~~ Session ended: ${JSON.stringify(handlerInput.requestEnvelope)}`);
        // Any cleanup logic goes here.
        return handlerInput.responseBuilder.getResponse(); // notice we send an empty response
    }
};
/* *
 * The intent reflector is used for interaction model testing and debugging.
 * It will simply repeat the intent the user said. You can create custom handlers for your intents 
 * by defining them above, then also adding them to the request handler chain below 
 * */
const IntentReflectorHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest';
    },
    handle(handlerInput) {
        const intentName = Alexa.getIntentName(handlerInput.requestEnvelope);
        const speakOutput = `Acabas de activar el intento ${intentName}`;
        
           if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            // generate the APL RenderDocument directive that will be returned from your skill
            const aplDirective = createDirectivePayload2(DOCUMENT_ID2, datasource2);
            // add the RenderDocument directive to the responseBuilder
            handlerInput.responseBuilder.addDirective(aplDirective);
        }

        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};
/**
 * Generic error handling to capture any syntax or routing errors. If you receive an error
 * stating the request handler chain is not found, you have not implemented a handler for
 * the intent being invoked or included it in the skill builder below 
 * */
const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        const speakOutput = 'Lo siento, no puedo realizar esa acción en este momento. Por favor, intenta de nuevo más tarde.';
        console.log(`~~ Error manejado: ${JSON.stringify(error)}`);
        
            if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            // generate the APL RenderDocument directive that will be returned from your skill
            const aplDirective = createDirectivePayload5(DOCUMENT_ID5, datasource5);
            // add the RenderDocument directive to the responseBuilder
            handlerInput.responseBuilder.addDirective(aplDirective);
        }

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

/**
 * This handler acts as the entry point for your skill, routing all request and response
 * payloads to the handlers above. Make sure any new handlers or interceptors you've
 * defined are included below. The order matters - they're processed top to bottom 
 * */
exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        informacionInstrumentosIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        FallbackIntentHandler,
        SessionEndedRequestHandler,
        IntentReflectorHandler)
    .addErrorHandlers(
        ErrorHandler)
    .withCustomUserAgent('sample/hello-world/v1.2')
    .lambda();
